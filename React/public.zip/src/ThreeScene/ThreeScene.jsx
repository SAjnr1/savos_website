import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'

const ThreeScene = () => {
  const mountRef = useRef(null)

  useEffect(() => {
    const container = mountRef.current

    if (!container) return

    // ==========================================
    // SCENE
    // ==========================================

    const scene = new THREE.Scene()

    // ==========================================
    // CAMERA
    // ==========================================

    const camera = new THREE.PerspectiveCamera(
      45,
      1,
      0.1,
      1000
    )

    // ==========================================
    // RENDERER
    // ==========================================

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false
    })

    renderer.setPixelRatio(
      Math.min(window.devicePixelRatio, 2)
    )

    renderer.setClearColor(0xf5f5f5, 1)

    renderer.outputColorSpace = THREE.SRGBColorSpace

    container.appendChild(renderer.domElement)

    // ==========================================
    // LIGHTING
    // ==========================================

    const ambientLight = new THREE.AmbientLight(
      0xffffff,
      2
    )

    scene.add(ambientLight)

    const keyLight = new THREE.DirectionalLight(
      0xffffff,
      4
    )

    keyLight.position.set(5, 5, 5)

    scene.add(keyLight)

    const fillLight = new THREE.DirectionalLight(
      0xffffff,
      2
    )

    fillLight.position.set(-5, 3, 2)

    scene.add(fillLight)

    const backLight = new THREE.DirectionalLight(
      0xffffff,
      2
    )

    backLight.position.set(0, 5, -5)

    scene.add(backLight)

    // ==========================================
    // MODEL
    // ==========================================

    let model = null

    const loader = new GLTFLoader()

    loader.load(
      '/models/ultrasonic-holder.glb',

      (gltf) => {
        console.log('3D model loaded successfully')

        model = gltf.scene

        // Add model to scene
        scene.add(model)

        // ======================================
        // CALCULATE MODEL BOUNDING BOX
        // ======================================

        const box = new THREE.Box3().setFromObject(model)

        const center = new THREE.Vector3()

        const size = new THREE.Vector3()

        box.getCenter(center)
        box.getSize(size)

        console.log('Model size:', size)
        console.log('Model center:', center)

        // ======================================
        // CENTER MODEL
        // ======================================

        model.position.x -= center.x
        model.position.y -= center.y
        model.position.z -= center.z

        // ======================================
        // SCALE MODEL
        // ======================================

        const maxDimension = Math.max(
          size.x,
          size.y,
          size.z
        )

        const desiredSize = 3

        if (maxDimension > 0) {
          const scale =
            desiredSize / maxDimension

          model.scale.setScalar(scale)
        }

        // ======================================
        // CAMERA POSITION
        // ======================================

        camera.position.set(
          0,
          0,
          5
        )

        camera.lookAt(
          0,
          0,
          0
        )

        // ======================================
        // KEEP ORIGINAL MODEL MATERIALS
        // ======================================

        model.traverse((object) => {
          if (object.isMesh) {

            object.castShadow = true
            object.receiveShadow = true

            // Make sure materials remain visible
            if (object.material) {
              object.material.needsUpdate = true
            }
          }
        })
      },

      // ========================================
      // LOADING PROGRESS
      // ========================================

      (xhr) => {
        if (xhr.total) {
          const percent =
            (xhr.loaded / xhr.total) * 100

          console.log(
            `Loading 3D model: ${percent.toFixed(0)}%`
          )
        }
      },

      // ========================================
      // ERROR
      // ========================================

      (error) => {
        console.error(
          'FAILED TO LOAD 3D MODEL:',
          error
        )
      }
    )

    // ==========================================
    // RESIZE
    // ==========================================

    const resize = () => {
      const width = container.clientWidth
      const height = container.clientHeight

      if (width === 0 || height === 0) return

      camera.aspect = width / height

      camera.updateProjectionMatrix()

      renderer.setSize(
        width,
        height,
        false
      )
    }

    resize()

    window.addEventListener(
      'resize',
      resize
    )

    // ==========================================
    // ANIMATION
    // ==========================================

    let animationFrameId

    const animate = () => {
      animationFrameId =
        requestAnimationFrame(animate)

      // ======================================
      // CONTINUOUS SLOW ROTATION
      // ======================================

      if (model) {
        model.rotation.y += 0.003
      }

      renderer.render(
        scene,
        camera
      )
    }

    animate()

    // ==========================================
    // CLEANUP
    // ==========================================

    return () => {
      cancelAnimationFrame(
        animationFrameId
      )

      window.removeEventListener(
        'resize',
        resize
      )

      if (
        container &&
        renderer.domElement
      ) {
        container.removeChild(
          renderer.domElement
        )
      }

      renderer.dispose()

      if (model) {
        model.traverse((object) => {
          if (object.isMesh) {

            if (object.geometry) {
              object.geometry.dispose()
            }

            if (object.material) {

              if (Array.isArray(object.material)) {
                object.material.forEach(
                  (material) => material.dispose()
                )
              } else {
                object.material.dispose()
              }
            }
          }
        })
      }
    }
  }, [])

  return (
    <div
      ref={mountRef}
      style={{
        width: '100%',
        height: '500px',
        overflow: 'hidden',
        position: 'relative'
      }}
    />
  )
}

export default ThreeScene