import React from 'react'
import './Programs.css'
import Navbar from '../../Components/Navbar/Navbar'
import ThreeScene from '../../ThreeScene/ThreeScene'
import program_1 from '../../assets/tomato-coating.png'
import program_2 from '../../assets/savos-ketchup.jpg'
import product_3 from '../../assets/savos_shito.png'
import program_icon_1 from '../../assets/tomato_coating.png'
import program_icon_2 from '../../assets/ketchup-bottle.png'
import program_icon_3 from '../../assets/shito-container.png'



const Programs = () => {
  return (
    <>
    <Navbar/>
    <ThreeScene/>
    <div className='programs' >
       <h1>PRODUCGT</h1>   
    </div>

    </>
  )
}
 
export default Programs